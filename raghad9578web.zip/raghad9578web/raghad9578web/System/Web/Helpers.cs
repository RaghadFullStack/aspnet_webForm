﻿namespace System.Web
{
    internal class Helpers
    {
    }
}