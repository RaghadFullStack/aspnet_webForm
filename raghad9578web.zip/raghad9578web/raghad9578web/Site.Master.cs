﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace raghad9578wa
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Highlight active page in navigation
                string currentPage = System.IO.Path.GetFileName(Request.Path);
                if (currentPage.Equals("Default.aspx", StringComparison.OrdinalIgnoreCase)) ;

            }
        }
    }
}